import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Settings, 
  ShieldCheck, 
  Zap, 
  Activity, 
  Battery, 
  Moon, 
  Sun,
  Info,
  Gamepad2,
  PhoneCall,
  Trees,
  AlertTriangle,
  ChevronRight,
  Waves,
  Cpu,
  Radio,
  Maximize2,
  Lock,
  Target,
  Sparkles,
  Bluetooth,
  Video,
  VideoOff,
  CircleStop,
  GripVertical,
  Minus,
  Plus,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type Profile = 'Gaming' | 'Messenger' | 'Outdoor' | 'Distance' | 'Custom';

interface AudioSettings {
  gain: number;
  noiseReduction: boolean;
  compression: boolean;
  bass: number;
  treble: number;
  sensitivity: number;
  distanceBoost: boolean;
  profile: Profile;
}

// --- Constants ---
const PROFILES: Record<Profile, Partial<AudioSettings>> = {
  Gaming: { gain: 2.5, noiseReduction: true, compression: true, bass: 5, treble: 8, distanceBoost: false },
  Messenger: { gain: 3.5, noiseReduction: true, compression: true, bass: 2, treble: 12, distanceBoost: false },
  Outdoor: { gain: 4.5, noiseReduction: false, compression: true, bass: 0, treble: 15, distanceBoost: true },
  Distance: { gain: 5.0, noiseReduction: true, compression: true, bass: 10, treble: 10, distanceBoost: true },
  Custom: {}
};

// --- Components ---

const RainbowMarquee = () => {
  const text = "আমার এই অ্যাপটি ব্যবহার করার জন্য আপনাদের অনেক অনেক ধন্যবাদ। আশা করি এই অ্যাপটি আপনাদের ভালো লাগবে।";
  
  return (
    <div className="w-full overflow-hidden bg-black/60 border-t border-white/10 py-4 backdrop-blur-2xl">
      <motion.div 
        animate={{ x: [0, -1000] }}
        transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
        className="whitespace-nowrap flex items-center"
      >
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex items-center">
            <motion.span
              animate={{ 
                backgroundImage: [
                  "linear-gradient(to right, #3b82f6, #8b5cf6, #ec4899)",
                  "linear-gradient(to right, #ec4899, #f59e0b, #10b981)",
                  "linear-gradient(to right, #10b981, #3b82f6, #8b5cf6)",
                  "linear-gradient(to right, #3b82f6, #8b5cf6, #ec4899)"
                ]
              }}
              transition={{ duration: 8, repeat: Infinity }}
              className="text-sm font-black uppercase tracking-widest bg-clip-text text-transparent px-4"
              style={{ WebkitBackgroundClip: 'text', backgroundClip: 'text' }}
            >
              {text}
            </motion.span>
            <span className="mx-12" />
          </div>
        ))}
      </motion.div>
    </div>
  );
};

export default function App() {
  // --- State ---
  const [isActive, setIsActive] = useState(true); // Auto-start enabled
  const [isTestMode, setIsTestMode] = useState(false);
  const [settings, setSettings] = useState<AudioSettings>({
    gain: 3.5,
    noiseReduction: true,
    compression: true,
    bass: 5,
    treble: 10,
    sensitivity: 0.8,
    distanceBoost: true,
    profile: 'Messenger'
  });
  const [audioLevel, setAudioLevel] = useState(0);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<'main' | 'eq' | 'advanced'>('main');
  
  // Floating Bubble State
  const [isBubbleExpanded, setIsBubbleExpanded] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  // --- Refs for Web Audio ---
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const compressorRef = useRef<DynamicsCompressorNode | null>(null);
  const bassFilterRef = useRef<BiquadFilterNode | null>(null);
  const trebleFilterRef = useRef<BiquadFilterNode | null>(null);
  const noiseFilterRef = useRef<BiquadFilterNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Recording Refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingIntervalRef = useRef<number | null>(null);

  // --- Audio Logic ---
  const stopAudio = useCallback(() => {
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
    }
    audioContextRef.current = null;
    streamRef.current = null;
    setAudioLevel(0);
  }, []);

  const startAudio = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true 
        } 
      });
      streamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      sourceRef.current = source;

      const noiseFilter = audioContext.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.value = settings.noiseReduction ? 180 : 20;
      noiseFilterRef.current = noiseFilter;

      const bassFilter = audioContext.createBiquadFilter();
      bassFilter.type = 'lowshelf';
      bassFilter.frequency.value = 250;
      bassFilter.gain.value = settings.bass;
      bassFilterRef.current = bassFilter;

      const trebleFilter = audioContext.createBiquadFilter();
      trebleFilter.type = 'highshelf';
      trebleFilter.frequency.value = 3500;
      trebleFilter.gain.value = settings.treble;
      trebleFilterRef.current = trebleFilter;

      const compressor = audioContext.createDynamicsCompressor();
      const threshold = settings.distanceBoost ? -45 : -24;
      const ratio = settings.distanceBoost ? 20 : 12;
      
      compressor.threshold.setValueAtTime(threshold, audioContext.currentTime);
      compressor.knee.setValueAtTime(40, audioContext.currentTime);
      compressor.ratio.setValueAtTime(ratio, audioContext.currentTime);
      compressor.attack.setValueAtTime(0.001, audioContext.currentTime);
      compressor.release.setValueAtTime(0.2, audioContext.currentTime);
      compressorRef.current = compressor;

      const gainNode = audioContext.createGain();
      gainNode.gain.value = settings.gain;
      gainNodeRef.current = gainNode;

      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      source.connect(noiseFilter);
      noiseFilter.connect(bassFilter);
      bassFilter.connect(trebleFilter);
      trebleFilter.connect(compressor);
      compressor.connect(gainNode);
      gainNode.connect(analyser);

      if (isTestMode) {
        gainNode.connect(audioContext.destination);
      }

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const draw = () => {
        if (!analyserRef.current || !canvasRef.current) return;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        analyserRef.current.getByteFrequencyData(dataArray);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const barWidth = (canvas.width / bufferLength) * 2;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = (dataArray[i] / 255) * canvas.height;
          const gradient = ctx.createLinearGradient(0, canvas.height, 0, 0);
          gradient.addColorStop(0, '#3b82f6');
          gradient.addColorStop(1, '#8b5cf6');
          ctx.fillStyle = gradient;
          ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
          x += barWidth + 2;
        }

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) sum += dataArray[i];
        setAudioLevel(sum / bufferLength);

        animationFrameRef.current = requestAnimationFrame(draw);
      };
      draw();

    } catch (err) {
      console.error('Mic Error:', err);
      setIsActive(false);
    }
  }, [settings.gain, settings.noiseReduction, settings.bass, settings.treble, settings.distanceBoost, isTestMode]);

  useEffect(() => {
    if (isActive) startAudio();
    else stopAudio();
    return () => stopAudio();
  }, [isActive, startAudio, stopAudio]);

  useEffect(() => {
    const now = audioContextRef.current?.currentTime || 0;
    if (gainNodeRef.current) gainNodeRef.current.gain.setTargetAtTime(settings.gain, now, 0.1);
    if (bassFilterRef.current) bassFilterRef.current.gain.setTargetAtTime(settings.bass, now, 0.1);
    if (trebleFilterRef.current) trebleFilterRef.current.gain.setTargetAtTime(settings.treble, now, 0.1);
    if (noiseFilterRef.current) noiseFilterRef.current.frequency.setTargetAtTime(settings.noiseReduction ? 180 : 20, now, 0.1);
    if (compressorRef.current) {
      compressorRef.current.threshold.setTargetAtTime(settings.distanceBoost ? -45 : -24, now, 0.1);
      compressorRef.current.ratio.setTargetAtTime(settings.distanceBoost ? 20 : 12, now, 0.1);
    }
  }, [settings.gain, settings.bass, settings.treble, settings.noiseReduction, settings.distanceBoost]);

  // --- Recording Logic ---
  const startRecording = async () => {
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({ 
        video: true, 
        audio: true 
      });
      
      const destination = audioContextRef.current?.createMediaStreamDestination();
      if (destination && sourceRef.current) {
        gainNodeRef.current?.connect(destination);
        
        if (displayStream.getAudioTracks().length > 0) {
          const displayAudioSource = audioContextRef.current?.createMediaStreamSource(displayStream);
          displayAudioSource?.connect(destination);
        }

        const combinedStream = new MediaStream([
          ...displayStream.getVideoTracks(),
          ...destination.stream.getAudioTracks()
        ]);

        const mediaRecorder = new MediaRecorder(combinedStream, { mimeType: 'video/webm' });
        mediaRecorderRef.current = mediaRecorder;
        recordedChunksRef.current = [];

        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) recordedChunksRef.current.push(e.data);
        };

        mediaRecorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `BoosterPro_Record_${Date.now()}.webm`;
          a.click();
          setIsRecording(false);
          setRecordingTime(0);
          if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
        };

        mediaRecorder.start();
        setIsRecording(true);
        
        recordingIntervalRef.current = window.setInterval(() => {
          setRecordingTime(prev => prev + 1);
        }, 1000);
      }
    } catch (err) {
      console.error('Recording Error:', err);
      alert('Screen recording failed. Please grant necessary permissions.');
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
  };

  const handleProfileChange = (profile: Profile) => {
    const p = PROFILES[profile];
    setSettings(prev => ({ ...prev, ...p, profile }));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`min-h-screen flex flex-col transition-all duration-700 ${isDarkMode ? 'bg-[#05070a] text-slate-100' : 'bg-slate-50 text-slate-900'} font-sans overflow-hidden`}>
      {/* Animated Background Glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1], x: [0, 50, 0], y: [0, 30, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute -top-20 -left-20 w-96 h-96 bg-blue-600/30 blur-[120px] rounded-full" 
        />
        <motion.div 
          animate={{ scale: [1, 1.3, 1], opacity: [0.1, 0.15, 0.1], x: [0, -40, 0], y: [0, -50, 0] }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute -bottom-20 -right-20 w-96 h-96 bg-purple-600/30 blur-[120px] rounded-full" 
        />
      </div>

      {/* Header */}
      <header className="px-6 py-6 flex items-center justify-between border-b border-white/5 backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <motion.div whileHover={{ rotate: 180 }} className="w-12 h-12 bg-gradient-to-tr from-blue-600 to-cyan-400 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/30">
            <Radio className="text-white" size={28} />
          </motion.div>
          <div>
            <h1 className="font-black text-2xl tracking-tighter uppercase italic leading-none">Booster <span className="text-blue-500">ULTRA</span></h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
              <p className="text-[9px] font-black text-blue-400/80 tracking-[0.3em] uppercase">Hyper-Engine v4.0</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-all border border-white/5">
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={() => setShowSettings(true)} className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-all border border-white/5">
            <Settings size={20} />
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-md mx-auto w-full px-6 py-8 space-y-8 overflow-y-auto custom-scrollbar relative">
        {/* Visualizer Stage */}
        <section className="relative aspect-video bg-black/60 rounded-[2.5rem] border border-white/10 overflow-hidden shadow-2xl group">
          <canvas ref={canvasRef} className="w-full h-full" width={400} height={200} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
          
          <div className="absolute top-4 right-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-black/40 backdrop-blur-md rounded-full border border-white/10">
              <Activity size={12} className="text-blue-500" />
              <span className="text-[10px] font-mono font-black text-blue-400 uppercase tracking-widest">Live_Feed</span>
            </div>
          </div>

          <div className="absolute bottom-6 left-8 right-8 flex items-end justify-between">
            <div className="space-y-1">
              <p className="text-[10px] font-black opacity-40 uppercase tracking-widest">Active Profile</p>
              <h4 className="text-lg font-black italic uppercase text-blue-500">{settings.profile}</h4>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black opacity-40 uppercase tracking-widest">Boost Factor</p>
              <p className="text-2xl font-black italic text-white">{(settings.gain * (settings.distanceBoost ? 1.5 : 1)).toFixed(1)}<span className="text-blue-500 text-sm ml-1">X</span></p>
            </div>
          </div>

          {!isActive && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 flex items-center justify-center backdrop-blur-sm bg-black/40">
              <div className="flex flex-col items-center gap-3">
                <div className="w-12 h-12 rounded-full border-2 border-white/10 flex items-center justify-center">
                  <Lock size={20} className="opacity-20" />
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-30">Engine Offline</p>
              </div>
            </motion.div>
          )}
        </section>

        {/* Tab Navigation */}
        <nav className="flex p-1.5 bg-white/5 rounded-[2rem] border border-white/5 backdrop-blur-md">
          {(['main', 'eq', 'advanced'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${
                activeTab === tab ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>

        <AnimatePresence mode="wait">
          {activeTab === 'main' && (
            <motion.div key="main" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="space-y-8">
              {/* Power Core */}
              <div className="flex flex-col items-center py-6">
                <motion.button
                  whileTap={{ scale: 0.85 }}
                  onClick={() => setIsActive(!isActive)}
                  className={`relative w-44 h-44 rounded-full flex flex-col items-center justify-center transition-all duration-700 ${
                    isActive ? 'bg-blue-600 shadow-[0_0_80px_rgba(37,99,235,0.5)]' : 'bg-slate-900/80 border border-white/10'
                  }`}
                >
                  <div className={`absolute inset-0 rounded-full border-8 border-white/5 ${isActive ? 'animate-pulse' : ''}`} />
                  <AnimatePresence mode="wait">
                    {isActive ? (
                      <motion.div key="on" initial={{ rotate: -90 }} animate={{ rotate: 0 }} exit={{ rotate: 90 }}>
                        <Mic size={56} className="text-white" />
                      </motion.div>
                    ) : (
                      <motion.div key="off" initial={{ rotate: 90 }} animate={{ rotate: 0 }} exit={{ rotate: -90 }}>
                        <MicOff size={56} className="text-slate-600" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <motion.span animate={{ opacity: isActive ? [1, 0.5, 1] : 0.3 }} transition={{ repeat: Infinity, duration: 2 }} className={`mt-3 text-[11px] font-black uppercase tracking-[0.3em] ${isActive ? 'text-white' : 'text-slate-600'}`}>
                    {isActive ? 'Ignited' : 'Locked'}
                  </motion.span>
                </motion.button>
              </div>

              {/* Pro Profiles */}
              <div className="grid grid-cols-2 gap-4">
                {(['Messenger', 'Distance', 'Gaming', 'Outdoor'] as Profile[]).map((p) => (
                  <button
                    key={p}
                    onClick={() => handleProfileChange(p)}
                    className={`p-5 rounded-[2rem] border transition-all duration-500 flex items-center gap-4 group ${
                      settings.profile === p ? 'bg-blue-600/10 border-blue-500 shadow-lg shadow-blue-500/10' : 'bg-white/5 border-white/5 text-slate-500 hover:border-white/20'
                    }`}
                  >
                    <div className={`p-3 rounded-2xl transition-colors ${settings.profile === p ? 'bg-blue-600 text-white' : 'bg-white/5'}`}>
                      {p === 'Messenger' && <PhoneCall size={20} />}
                      {p === 'Distance' && <Target size={20} />}
                      {p === 'Gaming' && <Gamepad2 size={20} />}
                      {p === 'Outdoor' && <Trees size={20} />}
                    </div>
                    <div className="text-left">
                      <span className={`block text-[11px] font-black uppercase tracking-wider ${settings.profile === p ? 'text-blue-500' : ''}`}>{p}</span>
                      <span className="text-[8px] font-bold opacity-40 uppercase">{p === 'Distance' ? 'Far-Field' : 'Optimized'}</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Master Slider */}
              <div className="p-8 bg-white/5 rounded-[2.5rem] border border-white/5 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5"><Sparkles size={64} /></div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/20 rounded-lg text-blue-500"><Maximize2 size={18} /></div>
                    <h3 className="font-black text-xs uppercase tracking-widest">Master Gain</h3>
                  </div>
                  <span className="text-lg font-mono font-black text-blue-500">{(settings.gain * 20).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="1" max="5" step="0.1"
                  value={settings.gain}
                  onChange={(e) => setSettings({ ...settings, gain: parseFloat(e.target.value), profile: 'Custom' })}
                  className="w-full h-4 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
                />
              </div>
            </motion.div>
          )}

          {activeTab === 'eq' && (
            <motion.div key="eq" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="p-8 bg-white/5 rounded-[2.5rem] border border-white/5 space-y-10">
                <div className="space-y-5">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Bass Core</span>
                    </div>
                    <span className="text-xs font-mono font-black text-blue-500">+{settings.bass}dB</span>
                  </div>
                  <input 
                    type="range" min="0" max="20" step="1"
                    value={settings.bass}
                    onChange={(e) => setSettings({ ...settings, bass: parseInt(e.target.value), profile: 'Custom' })}
                    className="w-full h-3 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
                  />
                </div>

                <div className="space-y-5">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                      <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Voice Sharpness</span>
                    </div>
                    <span className="text-xs font-mono font-black text-cyan-400">+{settings.treble}dB</span>
                  </div>
                  <input 
                    type="range" min="0" max="20" step="1"
                    value={settings.treble}
                    onChange={(e) => setSettings({ ...settings, treble: parseInt(e.target.value), profile: 'Custom' })}
                    className="w-full h-3 bg-slate-800 rounded-full appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'advanced' && (
            <motion.div key="advanced" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                {[
                  { id: 'noiseReduction', label: 'AI Noise Wall', sub: 'Filter Environment', icon: <Waves />, color: 'purple' },
                  { id: 'compression', label: 'Pro Normalizer', sub: 'Broadcast Leveling', icon: <Cpu />, color: 'blue' },
                  { id: 'distanceBoost', label: 'Far-Field Boost', sub: 'Distance Sensing', icon: <Target />, color: 'cyan' },
                  { id: 'test', label: 'Loopback Monitor', sub: 'Real-time Feedback', icon: <Bluetooth />, color: 'orange', isTest: true }
                ].map((item) => (
                  <div key={item.id} className="p-6 bg-white/5 rounded-[2rem] border border-white/5 flex items-center justify-between group hover:bg-white/10 transition-all">
                    <div className="flex items-center gap-5">
                      <div className={`p-4 bg-${item.color}-500/10 rounded-2xl text-${item.color}-500 group-hover:scale-110 transition-transform`}>
                        {item.icon}
                      </div>
                      <div>
                        <p className="text-sm font-black uppercase italic">{item.label}</p>
                        <p className="text-[9px] opacity-40 uppercase font-black tracking-widest">{item.sub}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        if (item.isTest) setIsTestMode(!isTestMode);
                        else setSettings({ ...settings, [item.id]: !((settings as any)[item.id]) });
                      }}
                      className={`w-16 h-8 rounded-full relative transition-all ${
                        (item.isTest ? isTestMode : (settings as any)[item.id]) ? 'bg-blue-600' : 'bg-slate-800'
                      }`}
                    >
                      <motion.div animate={{ x: (item.isTest ? isTestMode : (settings as any)[item.id]) ? 36 : 4 }} className="absolute top-1 left-0 w-6 h-6 bg-white rounded-full shadow-xl" />
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Pro Guide */}
        <section className="relative p-8 bg-gradient-to-br from-blue-600 via-indigo-700 to-purple-800 rounded-[3rem] text-white shadow-2xl overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:rotate-12 transition-transform"><Zap size={80} /></div>
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md"><PhoneCall size={24} /></div>
            <h3 className="font-black text-xl uppercase italic tracking-tight">Ultra Call Guide</h3>
          </div>
          <div className="space-y-4">
            {["Turn ON Booster and select 'Distance' if you are far from phone.", "Select 'Messenger' for high-clarity voice calls.", "Keep this app active in background for continuous boost."].map((step, i) => (
              <div key={i} className="flex gap-4 items-start">
                <span className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center shrink-0 text-xs font-black">{i+1}</span>
                <p className="text-xs font-bold opacity-90 leading-relaxed">{step}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="h-40" />
      </main>

      {/* Floating Controller Bubble (XRecorder Style) */}
      <motion.div 
        drag
        dragMomentum={false}
        className="fixed z-[200] touch-none"
        style={{ right: '20px', top: '40%' }}
      >
        <AnimatePresence>
          {isBubbleExpanded ? (
            <motion.div 
              initial={{ scale: 0, opacity: 0, x: 50 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              exit={{ scale: 0, opacity: 0, x: 50 }}
              className="bg-slate-900/95 backdrop-blur-3xl border border-white/20 rounded-[2.5rem] p-5 flex flex-col gap-5 shadow-[0_0_60px_rgba(0,0,0,0.8)] min-w-[220px]"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                  <span className="text-[11px] font-black uppercase tracking-widest text-blue-400">Pro Overlay</span>
                </div>
                <button onClick={() => setIsBubbleExpanded(false)} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
                  <X size={18} />
                </button>
              </div>

              {/* Volume/Boost Control */}
              <div className="space-y-3">
                <div className="flex justify-between text-[10px] font-black opacity-40 uppercase tracking-widest">
                  <span>Gain_Factor</span>
                  <span className="text-blue-500">{settings.gain.toFixed(1)}x</span>
                </div>
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setSettings(s => ({ ...s, gain: Math.max(1, s.gain - 0.5) }))}
                    className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-90 transition-all"
                  >
                    <Minus size={16} />
                  </button>
                  <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ width: `${(settings.gain / 5) * 100}%` }}
                      className="h-full bg-gradient-to-r from-blue-600 to-cyan-400"
                    />
                  </div>
                  <button 
                    onClick={() => setSettings(s => ({ ...s, gain: Math.min(5, s.gain + 0.5) }))}
                    className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center hover:bg-white/10 active:scale-90 transition-all"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Recording Control */}
              <button 
                onClick={isRecording ? stopRecording : startRecording}
                className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-lg ${
                  isRecording 
                    ? 'bg-red-600 shadow-red-600/30 animate-pulse' 
                    : 'bg-blue-600 shadow-blue-600/30 hover:bg-blue-500'
                }`}
              >
                {isRecording ? <CircleStop size={20} /> : <Video size={20} />}
                <span className="text-xs font-black uppercase tracking-widest">
                  {isRecording ? formatTime(recordingTime) : 'Start Record'}
                </span>
              </button>

              <div className="flex justify-center pt-2">
                <GripVertical size={20} className="opacity-20 cursor-grab active:cursor-grabbing" />
              </div>
            </motion.div>
          ) : (
            <motion.button
              whileHover={{ scale: 1.1, rotate: 5 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsBubbleExpanded(true)}
              className="w-16 h-16 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(37,99,235,0.5)] border-2 border-white/30 relative"
            >
              <AnimatePresence mode="wait">
                {isRecording ? (
                  <motion.div key="rec" animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity }}>
                    <CircleStop className="text-white" size={28} />
                  </motion.div>
                ) : (
                  <motion.div key="icon">
                    <Radio className="text-white" size={28} />
                  </motion.div>
                )}
              </AnimatePresence>
              {isActive && (
                <span className="absolute top-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-[#05070a] shadow-lg" />
              )}
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Footer Marquee */}
      <footer className="fixed bottom-0 left-0 right-0 z-[60]">
        <RainbowMarquee />
      </footer>

      {/* Settings Overlay */}
      <AnimatePresence>
        {showSettings && (
          <motion.div initial={{ opacity: 0, y: '100%' }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: '100%' }} className="fixed inset-0 z-[100] bg-[#05070a]/98 backdrop-blur-3xl p-10 flex flex-col">
            <div className="flex items-center justify-between mb-12">
              <h2 className="text-4xl font-black italic uppercase tracking-tighter">System <span className="text-blue-500">Core</span></h2>
              <button onClick={() => setShowSettings(false)} className="p-4 bg-white/5 rounded-full hover:bg-white/10 transition-all">
                <ChevronRight size={32} className="rotate-90" />
              </button>
            </div>

            <div className="space-y-10 overflow-y-auto flex-1 pr-2 custom-scrollbar">
              <div className="space-y-6">
                <label className="text-[11px] font-black uppercase tracking-[0.4em] text-blue-500">Engine Sensitivity</label>
                <div className="p-8 bg-white/5 rounded-[2.5rem] border border-white/5">
                  <input 
                    type="range" min="0" max="1" step="0.01"
                    value={settings.sensitivity}
                    onChange={(e) => setSettings({ ...settings, sensitivity: parseFloat(e.target.value) })}
                    className="w-full h-3 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
                  />
                </div>
              </div>

              <div className="p-8 bg-gradient-to-r from-blue-600/10 to-purple-600/10 rounded-[2.5rem] border border-blue-500/20 space-y-4">
                <div className="flex items-center gap-3 text-blue-400">
                  <ShieldCheck size={22} />
                  <h4 className="font-black text-base uppercase italic">Privacy Protocol</h4>
                </div>
                <p className="text-xs opacity-60 leading-relaxed font-bold italic">Booster Ultra processes all audio streams locally. We do not record, store, or share your voice data. 100% Secure.</p>
              </div>
            </div>

            <button onClick={() => setShowSettings(false)} className="mt-12 w-full py-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-[2.5rem] font-black uppercase tracking-[0.2em] shadow-2xl shadow-blue-600/40">Synchronize Engine</button>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
        
        input[type='range']::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 24px;
          height: 24px;
          background: white;
          border: 4px solid #3b82f6;
          border-radius: 50%;
          cursor: pointer;
          box-shadow: 0 0 15px rgba(59, 130, 246, 0.5);
        }
      `}</style>
    </div>
  );
}
